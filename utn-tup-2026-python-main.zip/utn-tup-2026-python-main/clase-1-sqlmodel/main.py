
import logging

from fastapi import Depends, FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from sqlmodel import (
    Session,
    select,
)

from api import login, permissions, roles, users
from api.middlewares.auth import JWTAuthMW
from api.middlewares.counter import CounterMW
from api.users import UserDB
from model.users import Country
from repositories import database
from repositories.database import create_db_and_tables
from repositories.seed import seed_roles_and_permissions, seed_user_roles
from utils.hash import hash_password

logger = logging.getLogger(__name__)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)

jwtAuthMW = JWTAuthMW()

app = FastAPI(dependencies=[Depends(jwtAuthMW.check_jwt)])
app.include_router(users.router)
app.include_router(login.router)
app.include_router(roles.router)
app.include_router(permissions.router)

counterMW = CounterMW()


@app.middleware("counter")
async def middle_ware_prueba(request: Request, call_next):
    return await counterMW.middle_ware_prueba(request, call_next)


# Registered last so it is the outermost middleware and answers preflight
# requests before auth runs.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*", "Authorization"],
)


def create_dummy_data():
    with Session(database.engine) as session:
        if session.exec(select(UserDB)).first():
            return
        country_names = [("Argentina", 1), ("Brasil", 2)]
        countries = [Country(name=name, id=id) for name, id in country_names]

        session.add_all(countries)
        session.commit()

        names_and_ages = [
            ("Martina Gómez", "mgomez@email.com", 28, 1),
            ("Santiago Fernández", "sfer@email.com", 34, 1),
            ("Valentina López", "vlo@email.com", 22, 1),
            ("Mateo Rodríguez", "mro@email.com", 45, 1),
            ("Camila Martínez", "cma@email.com", 19, 2),
            ("Lucas Pérez", "lpe@email.com", 31, 2),
            ("Sofía García", "sga@email.com", 27, 2),
            ("Nicolás Sánchez", "nsa@email.com", 40, 2),
            ("Julieta Díaz", "jdi@email.com", 24, 2),
            ("Tomás Romero", "tro@email.com", 37, 2),
        ]
        hashed_pwd = hash_password("123")
        users = [
            UserDB(name=name, email=email, age=age, country_id=country, password=hashed_pwd)
            for name, email, age, country in names_and_ages
        ]
        session.add_all(users)
        session.commit()

def create_roles_and_permissions():
    with Session(database.engine) as session:
        seed_roles_and_permissions(session)
        seed_user_roles(session)

@app.on_event("startup")
def on_startup():
    create_db_and_tables()
    create_dummy_data()
    create_roles_and_permissions()

