from typing import Annotated, Sequence

from fastapi import Query
from sqlmodel import col, select

from dependencies import SessionDep
from model.roles import REGULAR_ROLE, Role
from model.users import User, UserDB
from utils.hash import hash_password


class UserRepository:
    def __init__(self, session: SessionDep):
        self.session = session

    def fetch_users(
        self,
        offset: int = 0,
        limit: Annotated[int, Query(le=100)] = 100,
    )-> Sequence[UserDB]:
        statement = select(UserDB).offset(offset).limit(limit)
        result = self.session.exec(statement)
        users = result.all()
        return users

    def create_user(self, userBase: User) -> UserDB:
        hashed_pwd = hash_password(userBase.password)
        regular = self.session.exec(select(Role).where(col(Role.name) == REGULAR_ROLE)).first()
        user = UserDB(
            name=userBase.name,
            age=userBase.age,
            email=userBase.email,
            password=hashed_pwd,
            country_id=userBase.country_id,
            roles=[regular] if regular else [],
        )
        self.session.add(user)
        self.session.commit()
        self.session.refresh(user)
        return user

    def get_by_id(self, user_id: int) -> UserDB | None:
        return self.session.get(UserDB, user_id)

    def get_by_email(self, email: str) -> UserDB | None:
        statement = select(UserDB).where(col(UserDB.email) == email)
        result = self.session.exec(statement)
        return result.first()

    def search_by_name(self, name: str) -> Sequence[UserDB]:
        statement = select(UserDB).where(col(UserDB.name).like("%{}%".format(name)))
        result = self.session.exec(statement)
        return result.all()

    def fetch_adults(self) -> Sequence[UserDB]:
        statement = select(UserDB).where(UserDB.age >= 18)
        result = self.session.exec(statement)
        return result.all()

    def delete_user(self, user_id: int):
        user = self.session.get(UserDB, user_id)
        self.session.delete(user)
        self.session.commit()

    def update_user(self, user_id: int, user: User) -> UserDB | None:
        userDb = self.session.get(UserDB, user_id)
        if userDb:
            userDb.age = user.age
            userDb.name = user.name
            userDb.country_id = user.country_id
            self.session.add(userDb)
            self.session.commit()
            self.session.refresh(userDb)
        return userDb

    def add_role(self, user: UserDB, role: Role) -> UserDB:
        if role not in user.roles:
            user.roles.append(role)
            self.session.add(user)
            self.session.commit()
            self.session.refresh(user)
        return user

    def remove_role(self, user: UserDB, role: Role) -> UserDB:
        if role in user.roles:
            user.roles.remove(role)
            self.session.add(user)
            self.session.commit()
            self.session.refresh(user)
        return user
